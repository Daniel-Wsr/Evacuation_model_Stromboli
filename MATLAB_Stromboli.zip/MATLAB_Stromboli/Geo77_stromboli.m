%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------Net-Logo-Evacuation-Simulation------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%% Michael Erb, Daniel Janz, Annika Hiller and Daniel Weissenrieder
% michael.erb@student.uni-tuebingen.de
% daniel.janz2@gmx.de
% annika.hiller@student.uni-tuebingen.de
% daniel.weissenrieder@student.uni-tuebingen.de
%% 
clc
clear all
close all

%% Load Data
for i=1:10
    A_RAW{i} = importfile(['C:\Users\oem\Documents\Universität Tübingen\Master_Geowissenschaften\Geo_77\Strombo_26_04\Strombo_26_04\Strombo\export_data\Alpha_',num2str(i),'.csv'], [1, Inf]); % insert path (attention with numb to str) 
    B_RAW{i} = importfile(['C:\Users\oem\Documents\Universität Tübingen\Master_Geowissenschaften\Geo_77\Strombo_26_04\Strombo_26_04\Strombo\export_data\Bravo_',num2str(i),'.csv'], [1, Inf]); % insert path (attention with numb to str)
end
%% Set parameters
humans=150;     % total nr. of humans
locals=100;         % total nr. of locals
tourists=50;        % total nr. of tourists  

x=(0:1:99)';        % length of new label [start:step:end] in time [ticks]

%% Bring all Matrices to the same size and to a 3D matrix form

A=zeros(100,12,10);
B=zeros(100,12,10);
for s=1:10
    A(1:size(A_RAW{1,s},1),1:size(A_RAW{1,s},2),s)=A_RAW{1,s}(:,:);
    B(1:size(B_RAW{1,s},1),1:size(B_RAW{1,s},2),s)=B_RAW{1,s}(:,:); 
    A(:,1,s)=x;
    B(:,1,s)=x;
    A(:,3,s)=0; A(:,4,s)=0; A(:,7,s)=0; A(:,8,s)=0; A(:,11,s)=0; A(:,12,s)=0;   %set not needed cells to 0;
end

%Create Matrixes were 0 is displaces by NaN (exept between t=0 and t=10)
%For Simulation Alpha:
A_N=A;          
for q=10:100
    for d=1:10
        if A(q,2,d)==0 
            A_N(q,2,d)=NaN;
        end
        if A(q,6,d)==0 
            A_N(q,6,d)=NaN;
        end
        if A(q,10,d)==0
            A_N(q,10,d)=NaN;
        end
    end
end

%For Simulation Bravo:
B_N=B;          
for q=10:100
    for d=1:10
        if B(q,2,d)==0 
            B_N(q,2,d)=NaN;
        end
        if B(q,6,d)==0 
            B_N(q,6,d)=NaN;
        end
        if B(q,10,d)==0
            B_N(q,10,d)=NaN;
        end
    end
end
 
%% Calculations

% For Simulation Alpha

% Reads the rescued time per simulation and save the times for 100% rescued
% people in a new vector

t_human_100_A=zeros(10,1);
t_tourists_100_A=zeros(10,1);
t_locals_100_A=zeros(10,1);

for c=1:10
    for v=1:100
        if A_N(v,2,c)==humans
            t_human_100_A(c)=A(v,1,c);
        end
        if A_N(v,10,c)==tourists 
            t_tourists_100_A(c)=A(v,1,c);
        end
        if A_N(v,6,c)==locals 
            t_locals_100_A(c)=A(v,1,c);
        end
    end
end

% Calculate and save %-values in column 2(humans),7(lokals) und 11(tourists).

for c=1:10
        A_N(:,3,c)=A_N(:,2,c)./humans;
        A_N(:,7,c)=A_N(:,6,c)./locals;
        A_N(:,11,c)=A_N(:,10,c)./tourists;
end


% Calculate the mean values for each time step
mean_H_A=zeros(100,1);
mean_L_A=zeros(100,1);
mean_T_A=zeros(100,1);


for v=1:100
        mean_H_A(v)=nanmean(A_N(v,3,:));
        mean_L_A(v)=nanmean(A_N(v,7,:));
        mean_T_A(v)=nanmean(A_N(v,11,:));
end

% For Simulation Bravo

% Reads the rescued time per simulation and save the times for 100% rescued
% people in a new vector

t_human_100_B=zeros(10,1);
t_tourists_100_B=zeros(10,1);
t_locals_100_B=zeros(10,1);

for c=1:10
    for v=1:100
        if B_N(v,2,c)==humans
            t_human_100_B(c)=B(v,1,c);
        end
        if B_N(v,10,c)==tourists 
            t_tourists_100_B(c)=B(v,1,c);
        end
        if B_N(v,6,c)==locals 
            t_locals_100_B(c)=B(v,1,c);
        end
    end
end

% Calculate and save %-values in column 2(humans),7(lokals) und 11(tourists).

for c=1:10
        B_N(:,3,c)=B_N(:,2,c)./humans;
        B_N(:,7,c)=B_N(:,6,c)./locals;
        B_N(:,11,c)=B_N(:,10,c)./tourists;
end


% Calculate the mean values for each time step
mean_H_B=zeros(100,1);
mean_L_B=zeros(100,1);
mean_T_B=zeros(100,1);


for v=1:100
        mean_H_B(v)=nanmean(B_N(v,3,:));
        mean_L_B(v)=nanmean(B_N(v,7,:));
        mean_T_B(v)=nanmean(B_N(v,11,:));
end


%% Plots 

%For Simulation Alpha
% Plot abosolut rescued humans for simulation Alpha and for each simulation 


figure(4)
hold on
for t=1:10
    p1=plot(x,A_N(:,3,t)*100,'LineWidth',1,'color',[0.4,0.4,0.4])
    p2=plot(x,A_N(:,7,t)*100,'LineWidth',1,'color',[181/255, 227/255, 181/255])
    p3=plot(x,A_N(:,11,t)*100,'LineWidth',1,'color',[245/255, 224/255, 91/255]) 
end 

p4=plot(x,mean_H_A*100,'LineWidth',6,'color',[0,0,0])
p5=plot(x,mean_L_A*100,'LineWidth',6,'color',[100/255, 125/255, 100/255])
p6=plot(x,mean_T_A*100,'LineWidth',6,'color',[179/255, 163/255, 68/255])

title('Results of the evacuation point Alpha (ten simulations)','FontSize',40)
xlabel('time [ticks]','FontSize',26)
ylabel('rescued people [%]','FontSize',26)
lgd=legend([p1,p2,p3,p4,p5,p6],'humans', 'locals','tourists','mean humans','mean locals','mean tourists','Location','southeast')
set(gca,'linewidth',4)
set(gca,'FontSize',26)
set(lgd,'FontSize',26);
hold off

%For simulation Bravo
% Plot abosolut rescued humans for simulation Alpha and for each simulation

figure(5)
hold on
for t=1:10
    p7=plot(x,B_N(:,3,t)*100,'LineWidth',1,'color',[0.4,0.4,0.4])
    p8=plot(x,B_N(:,7,t)*100,'LineWidth',1,'color',[181/255, 227/255, 181/255])
    p9=plot(x,B_N(:,11,t)*100,'LineWidth',1,'color',[245/255, 224/255, 91/255])
end 

p10=plot(x,mean_H_B*100,'LineWidth',6,'color',[0,0,0])
p11=plot(x,mean_L_B*100,'LineWidth',6,'color',[100/255, 125/255, 100/255])
p12=plot(x,mean_T_B*100,'LineWidth',6,'color',[179/255, 163/255, 68/255])

title('Results of the evacuation point Bravo (ten simulations)','FontSize',40)
xlabel('time [ticks]','FontSize',26)
ylabel('rescued people [%]','FontSize',26)
lgd2=legend([p7,p8,p9,p10,p11,p12],'humans', 'locals','tourists','mean humans','mean locals','mean tourists','Location','southeast')
set(gca,'linewidth',4)
set(gca,'FontSize',26)
set(lgd2,'FontSize',26);
hold off

%Compared Alpha and Bravo

figure(6)
hold on
boxplot([t_human_100_A,t_human_100_B],'Labels',{'Humans A','Humans B'})
ylabel('time [ticks]')
hold off

figure(7)
hold on
boxplot([t_locals_100_A,t_tourists_100_A,t_locals_100_B,t_tourists_100_B],'Labels',{'Locals A','Tourists A','Locals B','Tourists B'})
ylabel('time [ticks]')
hold off